// Cart and billing functionality

function addToCart(itemId) {
    const menuItems = getMenuItems();
    const item = menuItems.find(i => i.id === itemId);
    
    if (!item) return;
    
    // Get price based on pricing type
    let itemPrice = item.price || 0;
    if (item.pricingType === 'piece' && item.pricePerPiece) {
        itemPrice = item.pricePerPiece;
    }
    
    const cart = getCart();
    const existingItem = cart.find(c => c.itemId === itemId);
    
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({
            itemId: itemId,
            quantity: 1,
            price: itemPrice,
            weight: item.weight || null,
            pricingType: item.pricingType || null
        });
    }
    
    saveCart(cart);
    updateCartDisplay();
    updateCartCount();
}

function removeFromCart(itemId) {
    const cart = getCart();
    const filteredCart = cart.filter(c => c.itemId !== itemId);
    saveCart(filteredCart);
    updateCartDisplay();
    updateCartCount();
}

function updateQuantity(itemId, change) {
    const cart = getCart();
    const item = cart.find(c => c.itemId === itemId);
    
    if (!item) return;
    
    item.quantity += change;
    
    if (item.quantity <= 0) {
        removeFromCart(itemId);
        return;
    }
    
    saveCart(cart);
    updateCartDisplay();
    updateCartCount();
}

function clearCart(silent = false) {
    if (!silent && !confirm('Are you sure you want to clear the cart?')) {
        return;
    }
    saveCart([]);
    updateCartDisplay();
    updateCartCount();
}

function calculateTotal() {
    const cart = getCart();
    return cart.reduce((total, item) => total + (item.price * item.quantity), 0);
}

function updateCartDisplay() {
    const cartItems = document.getElementById('cartItems');
    const cart = getCart();
    const menuItems = getMenuItems();
    
    if (cart.length === 0) {
        cartItems.innerHTML = `
            <div class="empty-state">
                <div class="empty-state-icon">🛒</div>
                <p>Your cart is empty</p>
            </div>
        `;
        document.getElementById('cartTotal').textContent = '0';
        return;
    }
    
    cartItems.innerHTML = cart.map(cartItem => {
        const menuItem = menuItems.find(m => m.id === cartItem.itemId);
        if (!menuItem) return '';
        
        const subtotal = cartItem.price * cartItem.quantity;
        const weightDisplay = cartItem.weight ? `${cartItem.weight}g` : (menuItem.weight ? `${menuItem.weight}g` : '');
        const pricingInfo = (cartItem.pricingType === 'piece' || menuItem.pricingType === 'piece') 
            ? ' (Per Piece)' 
            : (weightDisplay ? ` (${weightDisplay})` : '');
        
        return `
            <div class="cart-item">
                <div class="cart-item-image">
                    ${menuItem.image ? 
                        `<img src="${menuItem.image}" alt="${menuItem.name}" onerror="this.parentElement.innerHTML='🍰'">` : 
                        '🍰'
                    }
                </div>
                <div class="cart-item-info">
                    <div class="cart-item-name">${menuItem.name}</div>
                    <div class="cart-item-price">₹${cartItem.price.toFixed(2)} each${pricingInfo}</div>
                    <div class="cart-item-controls">
                        <button class="quantity-btn" onclick="updateQuantity('${cartItem.itemId}', -1)">-</button>
                        <span class="quantity-display">${cartItem.quantity}</span>
                        <button class="quantity-btn" onclick="updateQuantity('${cartItem.itemId}', 1)">+</button>
                        <button class="remove-item-btn" onclick="removeFromCart('${cartItem.itemId}')">Remove</button>
                    </div>
                </div>
                <div class="cart-item-total">₹${subtotal.toFixed(2)}</div>
            </div>
        `;
    }).join('');
    
    document.getElementById('cartTotal').textContent = calculateTotal().toFixed(2);
}

function updateCartCount() {
    const cart = getCart();
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    const cartCountEl = document.getElementById('cartCount');
    if (cartCountEl) {
        cartCountEl.textContent = totalItems;
    }
}

function generateBill() {
    const cart = getCart();
    const menuItems = getMenuItems();
    
    if (cart.length === 0) {
        alert('Your cart is empty!');
        return;
    }
    
    const billPrint = document.getElementById('billPrint');
    const total = calculateTotal();
    const date = new Date().toLocaleString('en-IN');
    
    let itemsHtml = '';
    cart.forEach(cartItem => {
        const menuItem = menuItems.find(m => m.id === cartItem.itemId);
        if (!menuItem) return;
        
        const subtotal = cartItem.price * cartItem.quantity;
        const weightDisplay = cartItem.weight ? `${cartItem.weight}g` : (menuItem.weight ? `${menuItem.weight}g` : '');
        const pricingInfo = (cartItem.pricingType === 'piece' || menuItem.pricingType === 'piece') 
            ? ' (Per Piece)' 
            : (weightDisplay ? ` (${weightDisplay})` : '');
        itemsHtml += `
            <div class="bill-item">
                <div>
                    <strong>${menuItem.name}</strong> (${menuItem.type === 'egg' ? 'Egg' : 'Eggless'})
                    <br>
                    <small>${cartItem.quantity} x ₹${cartItem.price.toFixed(2)}${pricingInfo}</small>
                </div>
                <div>₹${subtotal.toFixed(2)}</div>
            </div>
        `;
    });
    
    billPrint.innerHTML = `
        <div class="bill-content">
            <div class="bill-header">
                <h1>🍰 Home Baking</h1>
                <p>Invoice</p>
                <p>Date: ${date}</p>
            </div>
            <div class="bill-items">
                ${itemsHtml}
            </div>
            <div class="bill-total">
                <div>Total: ₹${total.toFixed(2)}</div>
            </div>
            <div style="text-align: center; margin-top: 2rem; padding-top: 2rem; border-top: 1px solid #000;">
                <p>Thank you for your order!</p>
            </div>
        </div>
    `;
    
    window.print();
}

function initializeCart() {
    // Cart button
    const cartBtn = document.getElementById('cartBtn');
    const cartSidebar = document.getElementById('cartSidebar');
    const cartOverlay = document.getElementById('cartOverlay');
    const closeCart = document.getElementById('closeCart');
    
    if (cartBtn) {
        cartBtn.addEventListener('click', () => {
            cartSidebar.classList.add('active');
            cartOverlay.classList.add('active');
            updateCartDisplay();
        });
    }
    
    if (closeCart) {
        closeCart.addEventListener('click', () => {
            cartSidebar.classList.remove('active');
            cartOverlay.classList.remove('active');
        });
    }
    
    if (cartOverlay) {
        cartOverlay.addEventListener('click', () => {
            cartSidebar.classList.remove('active');
            cartOverlay.classList.remove('active');
        });
    }
    
    // Clear cart button
    const clearCartBtn = document.getElementById('clearCart');
    if (clearCartBtn) {
        clearCartBtn.addEventListener('click', clearCart);
    }
    
    // Print bill button
    const printBillBtn = document.getElementById('printBill');
    if (printBillBtn) {
        printBillBtn.addEventListener('click', generateBill);
    }
    
    // Pay now button
    const payNowBtn = document.getElementById('payNow');
    if (payNowBtn) {
        payNowBtn.addEventListener('click', () => {
            const cart = getCart();
            if (cart.length === 0) {
                alert('Your cart is empty!');
                return;
            }
            
            const total = calculateTotal();
            document.getElementById('paymentAmount').textContent = total.toFixed(2);
            document.getElementById('qrModal').classList.add('active');
        });
    }
    
    // QR Modal
    const qrModal = document.getElementById('qrModal');
    const closeQR = document.getElementById('closeQR');
    
    if (closeQR) {
        closeQR.addEventListener('click', () => {
            qrModal.classList.remove('active');
        });
    }
    
    if (qrModal) {
        qrModal.addEventListener('click', (e) => {
            if (e.target === qrModal) {
                qrModal.classList.remove('active');
            }
        });
    }
    
    // Payment done button
    const paymentDoneBtn = document.getElementById('paymentDone');
    if (paymentDoneBtn) {
        paymentDoneBtn.addEventListener('click', () => {
            const cart = getCart();
            if (cart.length === 0) {
                alert('Your cart is empty!');
                return;
            }
            
            const total = calculateTotal();
            const order = {
                id: 'ORD-' + Date.now(),
                items: [...cart],
                total: total,
                date: new Date().toISOString(),
                status: 'completed'
            };
            
            saveOrder(order);
            clearCart(true); // Clear cart silently after payment
            document.getElementById('qrModal').classList.remove('active');
            // Close cart sidebar if open
            const cartSidebar = document.getElementById('cartSidebar');
            const cartOverlay = document.getElementById('cartOverlay');
            if (cartSidebar) cartSidebar.classList.remove('active');
            if (cartOverlay) cartOverlay.classList.remove('active');
            alert('Payment successful! Order placed.');
        });
    }
    
    // Initialize cart count
    updateCartCount();
}

// Initialize cart on page load
if (document.getElementById('cartBtn')) {
    initializeCart();
}

